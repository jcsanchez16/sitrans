
Link Tutorial:

https://www.iit.bme.hu/~soi/Rest_HelloWorld_Tutorial.pdf
