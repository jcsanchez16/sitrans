package vos;

public class VuelAndes
{
	public VuelAndes()
	{
		
	}
}
